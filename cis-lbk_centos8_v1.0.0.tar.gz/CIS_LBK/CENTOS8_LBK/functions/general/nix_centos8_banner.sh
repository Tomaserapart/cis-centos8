BANR()
{
	echo ""
	echo ""
	echo "     ######################################################## "
	echo "     #  CIS Linux Build Kit for CentOS Linux 8              # "
	echo "     #  This Linux Build Kit works in conjunction with the  # "
	echo "     #  CIS CentOS Linux 8 Benchmark v1.0.0                 # "
	echo "     #  This script is the property of:                     # "
	echo "     #  Center for Internet Security (CIS)                  # "
	echo "     ######################################################## "
	echo ""
	echo ""
}
# End of print bannor to Screen